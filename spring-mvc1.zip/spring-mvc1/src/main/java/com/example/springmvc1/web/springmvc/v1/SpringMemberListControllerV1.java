package com.example.springmvc1.web.springmvc.v1;

public class SpringMemberListControllerV1 {
}
